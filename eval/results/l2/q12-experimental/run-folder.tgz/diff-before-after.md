# removal checklist: /Users/Shared/eval-runs/q12-experimental/before -> /Users/Shared/eval-runs/q12-experimental/after

## bin-dirs.txt
action: remove the command (or uninstall the package that owns it)
- [ ] added: uv
- [ ] added: uvx

## brew-formulae_opt_homebrew.txt
action: brew uninstall --formula NAME (as the Homebrew owner); also brew services stop NAME
- [ ] added: uv 0.13.6

## test-user-processes.txt
action: quit the process (log the test user out, then sudo pkill -u NAME)
- [ ] removed or changed (restore?): evaluser         /System/Library/Frameworks/WebKit.framework/Versions/A/XPCServices/com.apple.WebKit.GPU.xpc/Contents/MacOS/com.apple.WebKit.GPU
- [ ] removed or changed (restore?): evaluser         /System/Library/Frameworks/WebKit.framework/Versions/A/XPCServices/com.apple.WebKit.Networking.xpc/Contents/MacOS/com.apple.WebKit.Networking
- [ ] removed or changed (restore?): evaluser         /System/Library/Frameworks/WebKit.framework/Versions/A/XPCServices/com.apple.WebKit.WebContent.xpc/Contents/MacOS/com.apple.WebKit.WebContent

## files outside the test home changed during the run
action: delete each file the run created (keep macOS's own updates); re-run snapshot afterwards
- [ ] /Users/Shared/eval-runs/q12-experimental/after/applications.txt
- [ ] /Users/Shared/eval-runs/q12-experimental/after/bin-dirs.txt
- [ ] /Users/Shared/eval-runs/q12-experimental/after/brew-casks_opt_homebrew.txt
- [ ] /Users/Shared/eval-runs/q12-experimental/after/brew-formulae_opt_homebrew.txt
- [ ] /Users/Shared/eval-runs/q12-experimental/after/brew-info_opt_homebrew.txt
- [ ] /Users/Shared/eval-runs/q12-experimental/after/brew-taps_opt_homebrew.txt
- [ ] /Users/Shared/eval-runs/q12-experimental/after/changed-outside-home.txt
- [ ] /Users/Shared/eval-runs/q12-experimental/after/etc-paths.txt
- [ ] /Users/Shared/eval-runs/q12-experimental/after/info.txt
- [ ] /Users/Shared/eval-runs/q12-experimental/after/launchd-plists.txt
- [ ] /Users/Shared/eval-runs/q12-experimental/after/listeners.txt
- [ ] /Users/Shared/eval-runs/q12-experimental/after/pkg-receipts.txt
- [ ] /Users/Shared/eval-runs/q12-experimental/after/test-user-processes.txt
- [ ] /Users/Shared/eval-runs/q12-experimental/after/users-shared.txt
- [ ] /Users/Shared/eval-runs/q12-experimental/after/users.txt
- [ ] /Users/Shared/eval-runs/q12-experimental/before/applications.txt
- [ ] /Users/Shared/eval-runs/q12-experimental/before/bin-dirs.txt
- [ ] /Users/Shared/eval-runs/q12-experimental/before/brew-casks_opt_homebrew.txt
- [ ] /Users/Shared/eval-runs/q12-experimental/before/brew-formulae_opt_homebrew.txt
- [ ] /Users/Shared/eval-runs/q12-experimental/before/brew-info_opt_homebrew.txt
- [ ] /Users/Shared/eval-runs/q12-experimental/before/brew-taps_opt_homebrew.txt
- [ ] /Users/Shared/eval-runs/q12-experimental/before/etc-paths.txt
- [ ] /Users/Shared/eval-runs/q12-experimental/before/launchd-plists.txt
- [ ] /Users/Shared/eval-runs/q12-experimental/before/listeners.txt
- [ ] /Users/Shared/eval-runs/q12-experimental/before/pkg-receipts.txt
- [ ] /Users/Shared/eval-runs/q12-experimental/before/test-user-processes.txt
- [ ] /Users/Shared/eval-runs/q12-experimental/before/users-shared.txt
- [ ] /Users/Shared/eval-runs/q12-experimental/before/users.txt
- [ ] /Users/Shared/eval-runs/q12-experimental/client-offline.json
- [ ] /Users/Shared/eval-runs/q12-experimental/client-offline.txt
- [ ] /Users/Shared/eval-runs/q12-experimental/client-online.json
- [ ] /Users/Shared/eval-runs/q12-experimental/client-online.txt
- [ ] /Users/Shared/eval-runs/q12-experimental/grader-requirements.lock
- [ ] /Users/Shared/eval-runs/q12-experimental/install-1.txt
- [ ] /Users/Shared/eval-runs/q12-experimental/install-2.txt
- [ ] /Users/Shared/eval-runs/q12-experimental/install-3.txt
- [ ] /Users/Shared/eval-runs/q12-experimental/install-4.txt
- [ ] /Users/Shared/eval-runs/q12-experimental/install.lines
- [ ] /Users/Shared/eval-runs/q12-experimental/listen-offline.txt
- [ ] /Users/Shared/eval-runs/q12-experimental/listen-online.txt
- [ ] /Users/Shared/eval-runs/q12-experimental/model-files.txt
- [ ] /Users/Shared/eval-runs/q12-experimental/net-state.txt
- [ ] /Users/Shared/eval-runs/q12-experimental/preflight.txt
- [ ] /Users/Shared/eval-runs/q12-experimental/scan-transcript.txt
- [ ] /Users/Shared/eval-runs/q12-experimental/server-offline-transcript.txt
- [ ] /Users/Shared/eval-runs/q12-experimental/server-online-transcript.txt
- [ ] /Users/Shared/eval-runs/q12-experimental/snapshot-after.log
- [ ] /Users/Shared/eval-runs/q12-experimental/snapshot-before.log
- [ ] /Users/Shared/eval-runs/q12-experimental/steps-transcript.txt
- [ ] /Users/Shared/eval-runs/q12-experimental/steps.txt
- [ ] /opt/homebrew/Cellar/uv/0.13.6/INSTALL_RECEIPT.json
- [ ] /opt/homebrew/Cellar/uv/0.13.6/sbom.spdx.json
- [ ] /opt/homebrew/bin/uv
- [ ] /opt/homebrew/bin/uvx
- [ ] /opt/homebrew/etc/bash_completion.d/uv
- [ ] /opt/homebrew/etc/bash_completion.d/uvx
- [ ] /opt/homebrew/opt/uv
- [ ] /opt/homebrew/share/fish/vendor_completions.d/uv.fish
- [ ] /opt/homebrew/share/fish/vendor_completions.d/uvx.fish
- [ ] /opt/homebrew/share/zsh/site-functions/_uv
- [ ] /opt/homebrew/share/zsh/site-functions/_uvx
- [ ] /opt/homebrew/var/homebrew/linked/uv
- [ ] /opt/homebrew/var/homebrew/locks/ca-certificates.formula.lock
- [ ] /opt/homebrew/var/homebrew/locks/cmake.formula.lock
- [ ] /opt/homebrew/var/homebrew/locks/libgit2.formula.lock
- [ ] /opt/homebrew/var/homebrew/locks/libssh2.formula.lock
- [ ] /opt/homebrew/var/homebrew/locks/llhttp.formula.lock
- [ ] /opt/homebrew/var/homebrew/locks/llvm.formula.lock
- [ ] /opt/homebrew/var/homebrew/locks/lz4.formula.lock
- [ ] /opt/homebrew/var/homebrew/locks/mpdecimal.formula.lock
- [ ] /opt/homebrew/var/homebrew/locks/ninja.formula.lock
- [ ] /opt/homebrew/var/homebrew/locks/openssl@4.formula.lock
- [ ] /opt/homebrew/var/homebrew/locks/pkgconf.formula.lock
- [ ] /opt/homebrew/var/homebrew/locks/python@3.15.formula.lock
- [ ] /opt/homebrew/var/homebrew/locks/readline.formula.lock
- [ ] /opt/homebrew/var/homebrew/locks/rust.formula.lock
- [ ] /opt/homebrew/var/homebrew/locks/sqlite.formula.lock
- [ ] /opt/homebrew/var/homebrew/locks/xz.formula.lock
- [ ] /opt/homebrew/var/homebrew/locks/z3.formula.lock
- [ ] /opt/homebrew/var/homebrew/locks/zstd.formula.lock

## large files in the test home (deleted with the account)
- /Users/evaluser/.cache/uv/archive-v0/HXQdagOKe_lAwbMC/mlx/lib/mlx.metallib
- /Users/evaluser/.local/share/uv/tools/mlx-lm/lib/python3.9/site-packages/mlx/lib/mlx.metallib
- /Users/evaluser/Library/Application Support/com.apple.wallpaper/aerials/videos/4C108785-A7BA-422E-9C79-B0129F1D5550.mov

4 section(s) to clean up
