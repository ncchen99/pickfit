# removal checklist: /Users/Shared/eval-runs/q12-control/before -> /Users/Shared/eval-runs/q12-control/after

## bin-dirs.txt
action: remove the command (or uninstall the package that owns it)
- [ ] added: uv
- [ ] added: uvx

## brew-formulae_opt_homebrew.txt
action: brew uninstall --formula NAME (as the Homebrew owner); also brew services stop NAME
- [ ] added: uv 0.13.6

## test-user-processes.txt
action: quit the process (log the test user out, then sudo pkill -u NAME)
- [ ] added: evaluser         /System/Cryptexes/App/usr/libexec/SafariBookmarksSyncAgent
- [ ] added: evaluser         /System/Library/Frameworks/MediaAccessibility.framework/Versions/A/XPCServices/com.apple.accessibility.mediaaccessibilityd.xpc/Contents/MacOS/com.apple.accessibility.mediaaccessibilityd
- [ ] added: evaluser         /System/Library/PrivateFrameworks/AvatarPersistence.framework/Support/avatarsd
- [ ] added: evaluser         /System/Library/PrivateFrameworks/CoreParsec.framework/parsec-fbf
- [ ] added: evaluser         /System/Library/PrivateFrameworks/ScreenTimeSettingsFoundation.framework/Versions/A/ScreenTimeSettingsAgent
- [ ] added: evaluser         /System/Library/PrivateFrameworks/UIFoundation.framework/Versions/A/XPCServices/nsattributedstringagent.xpc/Contents/MacOS/nsattributedstringagent
- [ ] removed or changed (restore?): evaluser         /System/Applications/System Settings.app/Contents/Resources/systemsettingsagent
- [ ] removed or changed (restore?): evaluser         /System/Library/PrivateFrameworks/WorkflowKit.framework/XPCServices/BackgroundShortcutRunner.xpc/Contents/MacOS/BackgroundShortcutRunner
- [ ] removed or changed (restore?): evaluser         /System/Volumes/Preboot/Cryptexes/App/System/Applications/Safari.app/Contents/Extensions/SafariWidgetExtension.appex/Contents/MacOS/SafariWidgetExtension
- [ ] removed or changed (restore?): evaluser         /usr/libexec/biomesyncd

## files outside the test home changed during the run
action: delete each file the run created (keep macOS's own updates); re-run snapshot afterwards
- [ ] /Library/Trial/NamespaceDescriptors/v2/globalActiveFactorProviders.plplist
- [ ] /Library/Trial/Treatments/PICKLED_RIND_BEACON/factorPacks/6a1e847dfae8a60fe3d88f20/factorPack.fb
- [ ] /Library/Trial/Treatments/PICKLED_RIND_BEACON/factorPacks/6a1e847dfae8a60fe3d88f20/factorPack.pb
- [ ] /Library/Trial/Treatments/PICKLED_RIND_BEACON/factorPacks/6a1e847dfae8a60fe3d88f20/onDemandFactorsSubscribedUserMap.plplist
- [ ] /Library/Trial/Treatments/PICKLED_RIND_CORAL/factorPacks/6a1e847ffae8a60fe3d88f21/factorPack.fb
- [ ] /Library/Trial/Treatments/PICKLED_RIND_CORAL/factorPacks/6a1e847ffae8a60fe3d88f21/factorPack.pb
- [ ] /Library/Trial/Treatments/PICKLED_RIND_CORAL/factorPacks/6a1e847ffae8a60fe3d88f21/onDemandFactorsSubscribedUserMap.plplist
- [ ] /Library/Trial/Treatments/PICKLED_RIND_MAGPIE/factorPacks/6a1e847fe5700036461dd986/factorPack.fb
- [ ] /Library/Trial/Treatments/PICKLED_RIND_MAGPIE/factorPacks/6a1e847fe5700036461dd986/factorPack.pb
- [ ] /Library/Trial/Treatments/PICKLED_RIND_MAGPIE/factorPacks/6a1e847fe5700036461dd986/onDemandFactorsSubscribedUserMap.plplist
- [ ] /Library/Trial/Treatments/PICKLED_RIND_PUMPKIN/factorPacks/6a1e848059a97e607a107573/factorPack.fb
- [ ] /Library/Trial/Treatments/PICKLED_RIND_PUMPKIN/factorPacks/6a1e848059a97e607a107573/factorPack.pb
- [ ] /Library/Trial/Treatments/PICKLED_RIND_PUMPKIN/factorPacks/6a1e848059a97e607a107573/onDemandFactorsSubscribedUserMap.plplist
- [ ] /Library/Trial/v7/AssetStore/assets/07/65a855f5a0caa8078a08539c/refs/link-2BD6AB43-6007-4D88-B2C7-12E59B116A5C
- [ ] /Library/Trial/v7/AssetStore/assets/07/65a855f5a0caa8078a08539c/refs/link-3EB44433-89AD-4C2A-929E-DDD8894EF6DF
- [ ] /Library/Trial/v7/AssetStore/assets/07/65a855f5a0caa8078a08539c/refs/link-86AD9C58-BD64-4C16-AE29-914F01AFF166
- [ ] /Library/Trial/v7/AssetStore/assets/07/65a855f5a0caa8078a08539c/refs/link-9D0426F3-B863-42AE-80F1-300C47E7863F
- [ ] /Library/Trial/v7/AssetStore/assets/3a/644aea85f726ab39ab630593/refs/link-21FA1EE0-8108-419E-B58D-4B86249AF9EC
- [ ] /Library/Trial/v7/AssetStore/assets/3a/644aea85f726ab39ab630593/refs/link-22C67335-0929-4171-8B32-8E9E7CC18B2A
- [ ] /Library/Trial/v7/AssetStore/assets/3a/644aea85f726ab39ab630593/refs/link-BBD46C07-143B-47E0-8A28-C1DEBE64AE4F
- [ ] /Library/Trial/v7/AssetStore/assets/3a/644aea85f726ab39ab630593/refs/link-BE074EF8-9C7A-4634-AB38-71DDB81E5EC0
- [ ] /Library/Trial/v7/AssetStore/assets/3e/6a1e847d59a97e607a107572/refs/link-9AA0304A-6142-49A1-B0A8-18B8F67D2677
- [ ] /Library/Trial/v7/AssetStore/assets/3e/6a1e847d59a97e607a107572/refs/link-BE0CC999-B6A4-4DD8-A879-39C44E6FF1D7
- [ ] /Library/Trial/v7/AssetStore/assets/3e/6a1e847d59a97e607a107572/refs/link-C5758D99-93C4-4F34-8999-0802E7AF6EED
- [ ] /Library/Trial/v7/AssetStore/assets/3e/6a1e847d59a97e607a107572/refs/link-F85135F0-D251-45B6-9741-108E0FED3077
- [ ] /Library/Trial/v7/AssetStore/assets/47/66a81e88321ffd6db066bb33/refs/link-132E1FDD-AC34-4C47-93C4-E14F74E377AB
- [ ] /Library/Trial/v7/AssetStore/assets/47/66a81e88321ffd6db066bb33/refs/link-7878E461-D450-4C25-AA75-3843DA506BBD
- [ ] /Library/Trial/v7/AssetStore/assets/47/66a81e88321ffd6db066bb33/refs/link-80DE8B7F-BC7C-478D-A588-819E5D67DA8A
- [ ] /Library/Trial/v7/AssetStore/assets/47/66a81e88321ffd6db066bb33/refs/link-A3EA0AAA-BF8E-4BE0-8FB1-E3FCA21161EE
- [ ] /Library/Trial/v7/AssetStore/assets/4f/6a1e847f34a0c07a068141ca/refs/link-21373F35-964A-4A57-9B99-71BD87EBEB9C
- [ ] /Library/Trial/v7/AssetStore/assets/4f/6a1e847f34a0c07a068141ca/refs/link-4794F5D1-7EE3-4844-B695-5B86B171BFB2
- [ ] /Library/Trial/v7/AssetStore/assets/4f/6a1e847f34a0c07a068141ca/refs/link-D55DCF4F-7B4A-4803-9452-A82E989B25BD
- [ ] /Library/Trial/v7/AssetStore/assets/4f/6a1e847f34a0c07a068141ca/refs/link-E2CB22AC-5F4F-4468-8594-ADBF44DCEB3E
- [ ] /Library/Trial/v7/AssetStore/assets/65/68d5908b1d01cb469a236623/refs/link-35E9241F-FA2A-42FC-9A70-3E92583E2639
- [ ] /Library/Trial/v7/AssetStore/assets/65/68d5908b1d01cb469a236623/refs/link-64E17F71-71E9-4F78-A1C8-473FF5C6DE73
- [ ] /Library/Trial/v7/AssetStore/assets/65/68d5908b1d01cb469a236623/refs/link-73B9FB83-5966-482C-9A6C-8A3BF0D575D7
- [ ] /Library/Trial/v7/AssetStore/assets/65/68d5908b1d01cb469a236623/refs/link-FE265CF6-1C44-4DE0-B449-0297CA2E39EE
- [ ] /Library/Trial/v7/AssetStore/assets/a5/663e65b46fc56f4670d6db91/refs/link-242D15F6-CAA9-46A1-AA06-4B08BD85624D
- [ ] /Library/Trial/v7/AssetStore/assets/a5/663e65b46fc56f4670d6db91/refs/link-33CB0F11-57EC-4D5A-9FF5-F2D55FD71518
- [ ] /Library/Trial/v7/AssetStore/assets/a5/663e65b46fc56f4670d6db91/refs/link-739A45E4-912B-4188-9A3D-8E047D7091D1
- [ ] /Library/Trial/v7/AssetStore/assets/a5/663e65b46fc56f4670d6db91/refs/link-B9CE541E-E90F-42C8-9980-69C87C4DB371
- [ ] /Library/Trial/v7/AssetStore/assets/c2/6a1e847eb4e6526b70f71055/refs/link-01D524D9-B619-487E-90C3-023088F208AD
- [ ] /Library/Trial/v7/AssetStore/assets/c2/6a1e847eb4e6526b70f71055/refs/link-C58E0A58-503B-43C8-A225-0E823A195A02
- [ ] /Library/Trial/v7/AssetStore/assets/c2/6a1e847eb4e6526b70f71055/refs/link-D6AC1F3C-0D32-498F-AEE7-C090A6730783
- [ ] /Library/Trial/v7/AssetStore/assets/c2/6a1e847eb4e6526b70f71055/refs/link-EBF818B8-C43A-425D-8E4D-FCF7D068BC6B
- [ ] /Library/Trial/v7/AssetStore/assets/d0/66d8b2f6246047489a40e3dd/refs/link-7812B20E-2301-4886-B636-41F0919C2FBE
- [ ] /Library/Trial/v7/AssetStore/assets/d0/66d8b2f6246047489a40e3dd/refs/link-81ED8F3D-B327-4C2A-80A1-6B93EC47751C
- [ ] /Library/Trial/v7/AssetStore/assets/d0/66d8b2f6246047489a40e3dd/refs/link-8A2AAA96-8E01-4697-A13B-57D9FD03B23D
- [ ] /Library/Trial/v7/AssetStore/assets/d0/66d8b2f6246047489a40e3dd/refs/link-C66C7EB1-8D06-4D51-90A1-915672AFC6DE
- [ ] /Library/Trial/v7/AssetStore/assets/e5/6a1e8480fae8a60fe3d88f22/refs/link-25D2E13C-72E2-439F-935D-40E31E052D46
- [ ] /Library/Trial/v7/AssetStore/assets/e5/6a1e8480fae8a60fe3d88f22/refs/link-54AC3AFA-C517-4DB2-8D2B-644F8BAC5089
- [ ] /Library/Trial/v7/AssetStore/assets/e5/6a1e8480fae8a60fe3d88f22/refs/link-7B768F55-6212-4B03-9437-33874E48A59C
- [ ] /Library/Trial/v7/AssetStore/assets/e5/6a1e8480fae8a60fe3d88f22/refs/link-CA076E46-6F70-49D5-BB20-51B663F01056
- [ ] /Library/Updates/ProductMetadata.plist
- [ ] /Users/Shared/eval-runs/q12-control/after/applications.txt
- [ ] /Users/Shared/eval-runs/q12-control/after/bin-dirs.txt
- [ ] /Users/Shared/eval-runs/q12-control/after/brew-casks_opt_homebrew.txt
- [ ] /Users/Shared/eval-runs/q12-control/after/brew-formulae_opt_homebrew.txt
- [ ] /Users/Shared/eval-runs/q12-control/after/brew-info_opt_homebrew.txt
- [ ] /Users/Shared/eval-runs/q12-control/after/brew-taps_opt_homebrew.txt
- [ ] /Users/Shared/eval-runs/q12-control/after/changed-outside-home.txt
- [ ] /Users/Shared/eval-runs/q12-control/after/etc-paths.txt
- [ ] /Users/Shared/eval-runs/q12-control/after/info.txt
- [ ] /Users/Shared/eval-runs/q12-control/after/launchd-plists.txt
- [ ] /Users/Shared/eval-runs/q12-control/after/listeners.txt
- [ ] /Users/Shared/eval-runs/q12-control/after/pkg-receipts.txt
- [ ] /Users/Shared/eval-runs/q12-control/after/test-user-processes.txt
- [ ] /Users/Shared/eval-runs/q12-control/after/users-shared.txt
- [ ] /Users/Shared/eval-runs/q12-control/after/users.txt
- [ ] /Users/Shared/eval-runs/q12-control/before/applications.txt
- [ ] /Users/Shared/eval-runs/q12-control/before/bin-dirs.txt
- [ ] /Users/Shared/eval-runs/q12-control/before/brew-casks_opt_homebrew.txt
- [ ] /Users/Shared/eval-runs/q12-control/before/brew-formulae_opt_homebrew.txt
- [ ] /Users/Shared/eval-runs/q12-control/before/brew-info_opt_homebrew.txt
- [ ] /Users/Shared/eval-runs/q12-control/before/brew-taps_opt_homebrew.txt
- [ ] /Users/Shared/eval-runs/q12-control/before/etc-paths.txt
- [ ] /Users/Shared/eval-runs/q12-control/before/launchd-plists.txt
- [ ] /Users/Shared/eval-runs/q12-control/before/listeners.txt
- [ ] /Users/Shared/eval-runs/q12-control/before/pkg-receipts.txt
- [ ] /Users/Shared/eval-runs/q12-control/before/test-user-processes.txt
- [ ] /Users/Shared/eval-runs/q12-control/before/users-shared.txt
- [ ] /Users/Shared/eval-runs/q12-control/before/users.txt
- [ ] /Users/Shared/eval-runs/q12-control/client-offline.json
- [ ] /Users/Shared/eval-runs/q12-control/client-offline.txt
- [ ] /Users/Shared/eval-runs/q12-control/client-online.json
- [ ] /Users/Shared/eval-runs/q12-control/client-online.txt
- [ ] /Users/Shared/eval-runs/q12-control/grader-requirements.lock
- [ ] /Users/Shared/eval-runs/q12-control/install-1.txt
- [ ] /Users/Shared/eval-runs/q12-control/install-2.txt
- [ ] /Users/Shared/eval-runs/q12-control/install-3.txt
- [ ] /Users/Shared/eval-runs/q12-control/install.lines
- [ ] /Users/Shared/eval-runs/q12-control/listen-offline.txt
- [ ] /Users/Shared/eval-runs/q12-control/listen-online.txt
- [ ] /Users/Shared/eval-runs/q12-control/model-files.txt
- [ ] /Users/Shared/eval-runs/q12-control/net-state.txt
- [ ] /Users/Shared/eval-runs/q12-control/preflight.txt
- [ ] /Users/Shared/eval-runs/q12-control/scan-transcript.txt
- [ ] /Users/Shared/eval-runs/q12-control/server-offline-transcript.txt
- [ ] /Users/Shared/eval-runs/q12-control/server-online-transcript.txt
- [ ] /Users/Shared/eval-runs/q12-control/snapshot-after.log
- [ ] /Users/Shared/eval-runs/q12-control/snapshot-before.log
- [ ] /Users/Shared/eval-runs/q12-control/steps-transcript.txt
- [ ] /Users/Shared/eval-runs/q12-control/steps.txt
- [ ] /opt/homebrew/Cellar/uv/0.13.6/INSTALL_RECEIPT.json
- [ ] /opt/homebrew/Cellar/uv/0.13.6/sbom.spdx.json
- [ ] /opt/homebrew/bin/uv
- [ ] /opt/homebrew/bin/uvx
- [ ] /opt/homebrew/etc/bash_completion.d/uv
- [ ] /opt/homebrew/etc/bash_completion.d/uvx
- [ ] /opt/homebrew/opt/uv
- [ ] /opt/homebrew/share/fish/vendor_completions.d/uv.fish
- [ ] /opt/homebrew/share/fish/vendor_completions.d/uvx.fish
- [ ] /opt/homebrew/share/zsh/site-functions/_uv
- [ ] /opt/homebrew/share/zsh/site-functions/_uvx
- [ ] /opt/homebrew/var/homebrew/linked/uv
- [ ] /opt/homebrew/var/homebrew/locks/ca-certificates.formula.lock
- [ ] /opt/homebrew/var/homebrew/locks/cmake.formula.lock
- [ ] /opt/homebrew/var/homebrew/locks/libgit2.formula.lock
- [ ] /opt/homebrew/var/homebrew/locks/libssh2.formula.lock
- [ ] /opt/homebrew/var/homebrew/locks/llhttp.formula.lock
- [ ] /opt/homebrew/var/homebrew/locks/llvm.formula.lock
- [ ] /opt/homebrew/var/homebrew/locks/lz4.formula.lock
- [ ] /opt/homebrew/var/homebrew/locks/mpdecimal.formula.lock
- [ ] /opt/homebrew/var/homebrew/locks/ninja.formula.lock
- [ ] /opt/homebrew/var/homebrew/locks/openssl@4.formula.lock
- [ ] /opt/homebrew/var/homebrew/locks/pkgconf.formula.lock
- [ ] /opt/homebrew/var/homebrew/locks/python@3.15.formula.lock
- [ ] /opt/homebrew/var/homebrew/locks/readline.formula.lock
- [ ] /opt/homebrew/var/homebrew/locks/rust.formula.lock
- [ ] /opt/homebrew/var/homebrew/locks/sqlite.formula.lock
- [ ] /opt/homebrew/var/homebrew/locks/xz.formula.lock
- [ ] /opt/homebrew/var/homebrew/locks/z3.formula.lock
- [ ] /opt/homebrew/var/homebrew/locks/zstd.formula.lock

## large files in the test home (deleted with the account)
- /Users/evaluser/.cache/uv/archive-v0/7Z6KIXAnl89_FR2P/mlx/lib/mlx.metallib
- /Users/evaluser/.local/share/uv/tools/mlx-lm/lib/python3.9/site-packages/mlx/lib/mlx.metallib
- /Users/evaluser/Library/Application Support/com.apple.wallpaper/aerials/videos/4C108785-A7BA-422E-9C79-B0129F1D5550.mov

4 section(s) to clean up
